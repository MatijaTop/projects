﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    internal class DatabaseContext : IDisposable
    {
        private readonly NorthwindEntities1 _context;

        public DatabaseContext()
        {
            _context = new NorthwindEntities1();
        }

        public NorthwindEntities1 GetContext()
        {
            return _context;
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
