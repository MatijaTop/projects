﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DataLayer;
using Domain;

namespace BuisnessLogic
{
    public class BLEmployee
    {
        private static BLEmployee instance = null;

        public static BLEmployee Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new BLEmployee();
                }
                return instance;
            }
        }

        public Employees e = Employees.Instance;
        public Employee GetEmployee(int id)
        {
            return e.GetEmployee(id);
        }

        public List<Employee> GetEmployees()
        {
            List<Employee> l = new List<Employee>();
            l = e.GetEmployees();
            return l;
        }

        public List<Employee> GetEmployees(string ime)
        {
            List<Employee> l = new List<Employee>();
            l = e.GetEmployees(ime);
            return l;
        }

        public bool UpdateEmployee(Employee em)
        {
            e.Update(em);
            return true;
        }

        public bool InsertEmployee(Employee em)
        {
            e.Insert(em);
            return true;
        }

        public bool DeleteEmployee(int id)
        {
            e.Delete(id);
            return true;
        }


    }
}
