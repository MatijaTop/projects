﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataLayer;
using Domain;

namespace BuisnessLogic
{
    public class BLSupplier
    {
        private static BLSupplier instance = null;
        public static BLSupplier Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new BLSupplier();
                }
                return instance;
            }
        }

        public Suppliers s = Suppliers.Instance;
        public Supplier GetSupplier(int id)
        {
            return s.GetSupplier(id);
        }

        public List<Supplier> GetSuppliers()
        {
            List<Supplier> l = new List<Supplier>();
            l = s.GetSuppliers();
            return l;
        }

        public List<Supplier> GetSuppliers(string ime)
        {
            List<Supplier> l = new List<Supplier>();
            l = s.GetSuppliers(ime);
            return l;
        }

        public bool UdpateSupplier(Supplier em)
        {
            s.Update(em);
            return true;
        }

        public bool Insert(Supplier em)
        {
            s.Insert(em);
            return true;
        }

        public bool DeleteSupplier(int id)
        {
            s.Delete(id);
            return true;
        }




    }
}
