﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using BuisnessLogic;
using Domain;

namespace PrviProjekatBraca
{
    public partial class frmGlavna : Form
    {
        BLEmployee BLEmployee = BLEmployee.Instance;
        BLSupplier BlSupplier = BLSupplier.Instance;
        public frmGlavna()
        {
            InitializeComponent();
            dataGridView1.DataSource = BLEmployee.GetEmployees();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
        }
        


        private void buttonIzmeni_Click(object sender, EventArgs e)
        {
            frmEmployee FrmEmployee = new frmEmployee();
            frmSupplier FrmSupplier = new frmSupplier();

            Employee emp = new Employee();
            Supplier sup = new Supplier();

            try
            {
                string baza = comboBox1.SelectedItem.ToString();
                string id = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                int i;
                Int32.TryParse(id, out i);
                if(baza.Equals("Tabela Employees"))
                {
                    emp = BLEmployee.GetEmployee(i);
                    FrmEmployee.e = emp;
                    FrmEmployee.ShowDialog();
                    BLEmployee.UpdateEmployee(emp);
                    dataGridView1.DataSource = BLEmployee.GetEmployees();
                }
                else
                {
                    sup = BlSupplier.GetSupplier(i);
                    FrmSupplier.s = sup;
                    FrmSupplier.ShowDialog();
                    BlSupplier.UdpateSupplier(sup);
                    dataGridView1.DataSource = BlSupplier.GetSuppliers();
                }
            }
            catch(Exception ex)
            {
                if (ex is ArgumentOutOfRangeException)
                    MessageBox.Show("Morate izabrati red koji zelite da izmenite.");
                else
                    MessageBox.Show("Greska prilikom izvrsetka Update-a");
                return;
            }
        }

        private void buttonDodaj_Click(object sender, EventArgs e)
        {
            frmEmployee FrmEmployee = new frmEmployee();
            frmSupplier FrmSupplier = new frmSupplier();
            Employee emp = new Employee();
            Supplier sup = new Supplier();

            try
            {
                string baza = comboBox1.SelectedItem.ToString();
                if (baza.Equals("Tabela Employees"))
                {
                    FrmEmployee.e = emp;
                    FrmEmployee.ShowDialog();
                    if (string.IsNullOrWhiteSpace(emp.Firstname) || string.IsNullOrWhiteSpace(emp.Lastname) || string.IsNullOrWhiteSpace(emp.Title))
                    {
                        dataGridView1.DataSource = BLEmployee.GetEmployees();
                    }
                    else
                    {
                        BLEmployee.InsertEmployee(emp);
                        dataGridView1.DataSource = BLEmployee.GetEmployees();
                    }

                }
                //else
                //{
                //    FrmSupplier.s = sup;
                //    FrmSupplier.ShowDialog();

                //    string Companyname = FrmSupplier.s.Companyname;
                //    string Contactname = FrmSupplier.s.Contactname;
                //    string Contacttitle = FrmSupplier.s.Contacttitle;
                //    if (string.IsNullOrWhiteSpace(Companyname) || string.IsNullOrWhiteSpace(Contactname) || string.IsNullOrWhiteSpace(Contacttitle))
                //    {
                //        dataGridView1.DataSource = BlSupplier.GetSuppliers();
                //    }
                //    else
                //    {
                //        BlSupplier.Insert(Companyname, Contactname, Contacttitle);
                //        dataGridView1.DataSource = BlSupplier.GetSuppliers();
                //    }
                //}
                else
                {
                    FrmSupplier.s = sup;
                    FrmSupplier.ShowDialog();
                    if (string.IsNullOrWhiteSpace(sup.Companyname) || string.IsNullOrWhiteSpace(sup.Contactname) || string.IsNullOrWhiteSpace(sup.Contacttitle))
                    {
                        dataGridView1.DataSource = BlSupplier.GetSuppliers();
                    }
                    else
                    {
                        BlSupplier.Insert(sup);
                        dataGridView1.DataSource = BlSupplier.GetSuppliers();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
                return;
            }
            
        }

        private void buttonObrisi_Click(object sender, EventArgs e)
        {
            try
            {
                int id;
                Int32.TryParse(dataGridView1.SelectedRows[0].Cells[0].Value.ToString(), out id);
                string baza = comboBox1.SelectedItem.ToString();
                if(baza.Equals("Tabela Employees"))
                {
                    BLEmployee.DeleteEmployee(id);
                    dataGridView1.DataSource = BLEmployee.GetEmployees();
                }
                else
                {
                    BlSupplier.DeleteSupplier(id);
                    dataGridView1.DataSource = BlSupplier.GetSuppliers();
                }
                Update();
            }
            catch (Exception ex)
            {
                if (ex is ArgumentOutOfRangeException)
                    MessageBox.Show("Morate izabrati ceo red koji zelite da izmenite.");
                else
                    MessageBox.Show("Greska prilikom procedure za brisanje.");
                return;
            }
        }

        private void buttonPretraga_Click(object sender, EventArgs e)
        {
            string ime = textIme.Text;
            string baza = comboBox1.SelectedItem.ToString();
            if (baza.Equals("Tabela Employees"))
            {
                dataGridView1.DataSource = BLEmployee.GetEmployees(ime);
            }
            else
            {
                dataGridView1.DataSource = BlSupplier.GetSuppliers(ime);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string baza = comboBox1.SelectedItem.ToString();
            if (baza.Equals("Tabela Employees"))
                dataGridView1.DataSource = BLEmployee.GetEmployees();
            else
                dataGridView1.DataSource = BlSupplier.GetSuppliers();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textIme_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
