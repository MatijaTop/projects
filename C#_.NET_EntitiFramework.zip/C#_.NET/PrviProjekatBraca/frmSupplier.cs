﻿using Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrviProjekatBraca
{
    public partial class frmSupplier : Form
    {
        public Supplier s;
        public bool inserted = false;
        public frmSupplier()
        {
            InitializeComponent();
        }

        private void frmSupplier_Load(object sender, EventArgs e)
        {
            if (this.s.Supplierid != 0)
            {
                textCompanyName.Text = this.s.Companyname;
                textContactName.Text = this.s.Contactname;
                textContactTitle.Text = this.s.Contacttitle;
            }
            else
                buttonSacuvaj.Text = "Sacuvaj";

        }
        private void buttonSacuvaj_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textCompanyName.Text) || string.IsNullOrWhiteSpace(textContactName.Text) || string.IsNullOrWhiteSpace(textContactTitle.Text))
            {
                MessageBox.Show("Sva polja moraju biti popunjena!", "Greska!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if(this.s.Supplierid != 0)
            {
                this.s.Companyname = textCompanyName.Text;
                this.s.Contactname = textContactName.Text;
                this.s.Contacttitle = textContactTitle.Text;
            }
            else
            {
                this.s.Companyname = textCompanyName.Text;
                this.s.Contactname = textContactName.Text;
                this.s.Contacttitle = textContactTitle.Text;
                this.s.Address = "";
                this.s.City = "";
                this.s.Region = "";
                this.s.Postalcode = "";
                this.s.Country = "";
                this.s.Phone = "";
                this.s.Fax = "";
                MessageBox.Show("Uspesno!");
                inserted = true;
            }
            this.Close();
        }

        private void frmSupplier_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textCompanyName_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
