﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Domain;

namespace PrviProjekatBraca
{
    public partial class frmEmployee : Form
    {
        public frmEmployee()
        {
            InitializeComponent();
        }
        public Employee e;

        private void Form2_Load(object sender, EventArgs e)
        {
            if(this.e.Empid != 0)
            {
                textIme.Text = this.e.Firstname;
                textPrezime.Text = this.e.Lastname;
                textTitula.Text = this.e.Title;
                buttonIzmeni.Text = "Izmeni";
            }
            else
            {
                buttonIzmeni.Text = "Sacuvaj";
            }
        }

        private void buttonIzmeni_Click(object sender, EventArgs e)
        {
            if(this.e.Empid != 0)
            {
                this.e.Firstname = textIme.Text;
                this.e.Lastname = textPrezime.Text;
                this.e.Title = textTitula.Text;
            }
            else
            {
                this.e.Firstname = textIme.Text;
                this.e.Lastname = textPrezime.Text;
                this.e.Title = textTitula.Text;
                this.e.Titleofcourtesy = "";
                this.e.Birthdate = null;
                this.e.Hiredate = null;
                this.e.Address = "";
                this.e.City = "";
                this.e.Region = "";
                this.e.Postalcode = "";
                this.e.Country = "";
                this.e.Phone = "";
                MessageBox.Show("Uspesno ste uneli novi red.");
            }
            this.Close();
        }

        private void textPrezime_TextChanged(object sender, EventArgs e)
        {

        }

        private void textIme_TextChanged(object sender, EventArgs e)
        {

        }

        private void textTitula_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
