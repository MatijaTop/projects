﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Domain;

namespace DataLayer
{
    public class Suppliers
    {
        private static Suppliers instance = null;
        public static Suppliers Instance
        {
            get
            {
                if(instance == null)
                {
                    instance = new Suppliers();
                }
                return instance;
            }
        }

        SqlConnection sc = new SqlConnection();
        SqlDataAdapter daSuppliers = new SqlDataAdapter();
        public DataTable dtSuppliers = new DataTable();


        public Suppliers()
        {
            var nw = ConfigurationManager.ConnectionStrings["TSQL"];
            sc.ConnectionString = nw.ConnectionString;
            sc.Open();

            dtSuppliers.Clear();
            var cmd = sc.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM [TSQL].[Production].[Suppliers]";
            daSuppliers.SelectCommand = cmd;
            SqlCommandBuilder cb = new SqlCommandBuilder(daSuppliers);

            daSuppliers.Fill(dtSuppliers);
            daSuppliers.UpdateCommand = cb.GetUpdateCommand();
            sc.Close();
        }

        void FillSuppliers()
        {
            if (sc.State != ConnectionState.Closed)
                sc.Open();
            dtSuppliers.Clear();
            var cmd = sc.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM [TSQL].[Production].[Suppliers]";
            daSuppliers.SelectCommand = cmd;
            SqlCommandBuilder cb = new SqlCommandBuilder(daSuppliers);

            daSuppliers.Fill(dtSuppliers);
            daSuppliers.UpdateCommand = cb.GetUpdateCommand();
            sc.Close();
        }

        public bool InsertData(string Companyname, string Contactname, string Contacttitle)
        {
            if (sc.State == ConnectionState.Closed)
                sc.Open();

            using (SqlTransaction tran = sc.BeginTransaction())
            {
                try
                {
                    var cmd = sc.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = cmd.CommandText = "INSERT INTO Production.Suppliers(companyname, contactname, contacttitle, address, city, region, postalcode, country, phone, fax)" + "values('" + Companyname + "', '" + Contactname + "', '" + Contacttitle + "', '', '', '', '', '', '', '')";
                    sc.Open();
                    cmd.ExecuteNonQuery();
                    tran.Commit();
                    return true;
                }

                catch
                {
                    tran.Rollback();
                    return false;
                }
            }
        }

        private Supplier Convert(DataRow dr)
        {
            Supplier s = new Supplier();
            s.Supplierid = Int32.Parse(dr["supplierid"].ToString());
            s.Companyname = dr["companyname"].ToString();
            s.Contactname = dr["contactname"].ToString();
            s.Contacttitle = dr["contacttitle"].ToString();
            s.Address = dr["address"].ToString();
            s.City = dr["city"].ToString();
            s.Region = dr["region"].ToString();
            s.Postalcode = dr["postalcode"].ToString();
            s.Country = dr["country"].ToString();
            s.Phone = dr["phone"].ToString();
            s.Fax = dr["fax"].ToString();

            return s;
        }

        public Supplier GetSupplier(int id)
        {
            return Convert(dtSuppliers.Select("supplierid = " + id.ToString())[0]);
        }

        public List<Supplier> GetSuppliers()
        {
            List<Supplier> l = new List<Supplier>();
            foreach (DataRow dr in dtSuppliers.Rows)
            {
                l.Add(Convert(dr));
            }
            return l;
        }

        public List<Supplier> GetSuppliers(string ime)
        {
            return dtSuppliers.AsEnumerable()
                .Where(dr => dr.Field<string>("Companyname").StartsWith(ime))
                .Select(dr => Convert(dr))
                .ToList();
        }

        void Update()
        {
            daSuppliers.Update(dtSuppliers);
            FillSuppliers();
        }

        public bool Update (Supplier em)
        {
            DataRow dr = dtSuppliers.Select("supplierid = " + em.Supplierid.ToString())[0];
            dr["supplierid"] = em.Supplierid.ToString();
            dr["companyname"] = em.Companyname.ToString();
            dr["contactname"] = em.Contactname.ToString();
            dr["contacttitle"] = em.Contactname.ToString();
            dr["address"] = em.Address.ToString();
            dr["city"] = em.City.ToString();
            dr["region"] = em.Region.ToString();
            dr["postalcode"] = em.Postalcode.ToString();
            dr["country"] = em.Country.ToString();
            dr["phone"] = em.Phone.ToString();
            dr["fax"] = em.Fax.ToString();

            Update();
            return true;
        }

        public bool Insert(Supplier em)
        {
            DataRow dr = dtSuppliers.NewRow();
            dr["supplierid"] = em.Supplierid.ToString();
            dr["companyname"] = em.Companyname.ToString();
            dr["contactname"] = em.Contactname.ToString();
            dr["contacttitle"] = em.Contactname.ToString();
            dr["address"] = em.Address.ToString();
            dr["city"] = em.City.ToString();
            dr["region"] = em.Region.ToString();
            dr["postalcode"] = em.Postalcode.ToString();
            dr["country"] = em.Country.ToString();
            dr["phone"] = em.Phone.ToString();
            dr["fax"] = em.Fax.ToString();

            dtSuppliers.Rows.Add(dr);
            Update();
            FillSuppliers();
            return true;
        }

        public bool Delete(int id)
        {
            dtSuppliers.Select("supplierid = " + id.ToString())[0].Delete();
            Update();
            return true;
        }

    }
}
