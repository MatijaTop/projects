﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.Net;
using Domain;

namespace DataLayer
{
    public class Employees
    {
        private static Employees instance = null;
        public static Employees Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Employees();
                }
                return instance;
            }
        }

        SqlConnection sc = new SqlConnection();
        SqlDataAdapter daEmployees = new SqlDataAdapter();
        public DataTable dtEmployees = new DataTable();

        public Employees()
        {
            var nw = ConfigurationManager.ConnectionStrings["TSQL"];
            sc.ConnectionString = nw.ConnectionString;
            sc.Open();

            dtEmployees.Clear();    
            var cmd = sc.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM [TSQL].[HR].[Employees]";
            ///cmd.CommandText = "SELECT * FROM [HR].[Employees]";
            daEmployees.SelectCommand = cmd;
            SqlCommandBuilder cb = new SqlCommandBuilder(daEmployees);

            daEmployees.Fill(dtEmployees);
            daEmployees.UpdateCommand = cb.GetUpdateCommand();
            sc.Close();
        }

        void FillEmployees()
        {
            if (sc.State != ConnectionState.Closed)                  ///!
                sc.Open();
            dtEmployees.Clear();
            var cmd = sc.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM [TSQL].[HR].[Employees]";
            daEmployees.SelectCommand = cmd;
            SqlCommandBuilder cb = new SqlCommandBuilder(daEmployees); ///!

            daEmployees.Fill(dtEmployees);
            daEmployees.UpdateCommand = cb.GetUpdateCommand();
            sc.Close();
        }

        public bool InsertData(string Name, string LastName, string Title)
        {
            if (sc.State == ConnectionState.Closed)
                sc.Open();

            using (SqlTransaction tran = sc.BeginTransaction())
            {
                try
                {
                    var cmd = sc.CreateCommand();
                    cmd.CommandType = CommandType.Text;
                    cmd.CommandText = "INSERT INTO HR.Employees(firstname, lastname, title, " + " titleofcourtesy, birthdate, hiredate, address, city, region, postalcode, country, phone)" + "values('@Name', '@LastName', '@Title', '', '', '', '', '', '', '', '', '')";
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@Name", Name);
                    cmd.Parameters.AddWithValue("@LastName", LastName);
                    cmd.Parameters.AddWithValue("@Title", Title);
                    sc.Open();
                    cmd.ExecuteNonQuery();
                    tran.Commit();
                    Update();
                    FillEmployees();
                    return true;
                }

                catch
                {
                    tran.Rollback();
                    return false;
                }
            }    
        }

        private Employee Convert(DataRow dr)                
        {
            Employee e = new Employee();
            e.Empid = Int32.Parse(dr["empid"].ToString());   
            e.Lastname = dr["lastname"].ToString();
            e.Firstname = dr["firstname"].ToString();
            e.Title = dr["title"].ToString();
            e.Titleofcourtesy = dr["titleofcourtesy"].ToString();
            e.Birthdate = DateTime.Parse(dr["birthdate"].ToString()); 
            e.Hiredate = DateTime.Parse(dr["hiredate"].ToString());
            e.Address = dr["address"].ToString();
            e.City = dr["city"].ToString();
            e.Region = dr["region"].ToString();
            e.Postalcode = dr["postalcode"].ToString();
            e.Country = dr["country"].ToString();
            e.Phone = dr["phone"].ToString();

            int mgrid;
            int.TryParse(dr["mgrid"].ToString(), out mgrid);  
            e.Mgrid = mgrid;
            return e;
        }

        public Employee GetEmployee(int id)
        {
            return Convert(dtEmployees.Select("empid = " + id.ToString())[0]);  ///!
        }

        public List<Employee> GetEmployees()             ///!
        {
            List<Employee> l = new List<Employee>();
            foreach (DataRow dr in dtEmployees.Rows)
            {
                l.Add(Convert(dr));
            }
            return l;
        }

        public List<Employee> GetEmployees(string ime)          ///!!!!!
        {
            return dtEmployees.AsEnumerable()
                .Where(dr => dr.Field<string>("Firstname").StartsWith(ime))
                .Select(dr => Convert(dr))
                .ToList();
        }

        void Update()
        {
            daEmployees.Update(dtEmployees);
            FillEmployees();
        }

        public bool Update(Employee em)
        {
            DataRow dr = dtEmployees.Select("empid = " + em.Empid.ToString())[0];
            dr["empid"] = em.Empid.ToString();
            dr["Lastname"] = em.Lastname.ToString();
            dr["Firstname"] = em.Firstname.ToString();
            dr["Title"] = em.Title.ToString();
            dr["Titleofcourtesy"] = em.Titleofcourtesy.ToString();
            dr["Birthdate"] = em.Birthdate;
            dr["Hiredate"] = em.Hiredate;
            dr["Address"] = em.Address;
            dr["City"] = em.City;
            dr["Region"] = em.Region;
            dr["Postalcode"] = em.Postalcode;
            dr["Country"] = em.Country;
            dr["Phone"] = em.Phone;

            Update();
            return true;
        }

        public bool Insert(Employee em)
        {
            DataRow dr = dtEmployees.NewRow();
            dr["empid"] = em.Empid.ToString();
            dr["Lastname"] = em.Lastname.ToString();
            dr["Firstname"] = em.Firstname.ToString();
            dr["Title"] = em.Title.ToString();
            dr["Titleofcourtesy"] = em.Titleofcourtesy.ToString();
            dr["Birthdate"] = em.Birthdate ?? DateTime.Parse("1900-01-01");
            dr["Hiredate"] = em.Hiredate ?? DateTime.Parse("1900-01-01");
            dr["Address"] = em.Address;
            dr["City"] = em.City;
            dr["Region"] = em.Region;
            dr["Postalcode"] = em.Postalcode;
            dr["Country"] = em.Country;
            dr["Phone"] = em.Phone;

            dtEmployees.Rows.Add(dr);
            Update();
            FillEmployees();
            return true;
        }

        public bool Delete(int id)
        {
            dtEmployees.Select("empid = " + id.ToString())[0].Delete();
            Update();
            return true;
        }

    }
}
